-- get the average of the values in the price column

SELECT AVG(price)
FROM purchases;