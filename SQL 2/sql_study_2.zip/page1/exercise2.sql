-- get rows from the character_name column with duplicates excluded

SELECT DISTINCT(character_name)
FROM purchases;