-- get the number of rows where character_name is "Ken the Ninja"

SELECT COUNT(*)
FROM purchases
WHERE character_name = "Ken the Ninja"
;