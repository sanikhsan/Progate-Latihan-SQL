-- delete the record with the id of 7 within the students table
DELETE FROM students WHERE id=7;
-- do not delete the following query
SELECT * FROM students;
