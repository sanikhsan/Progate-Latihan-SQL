-- get all columns from the "purchases" table

SELECT * FROM purchases;