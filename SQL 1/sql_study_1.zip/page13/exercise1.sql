-- after "FROM purchases" add code to get a result of a maximum of 5 rows

SELECT *
FROM purchases
LIMIT 5;