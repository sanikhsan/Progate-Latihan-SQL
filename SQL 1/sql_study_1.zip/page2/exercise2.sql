-- get the "price" column from the "purchases" table
SELECT price FROM purchases;


