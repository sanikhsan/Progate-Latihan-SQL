-- get the average profit value for all products
SELECT AVG(price - cost)
FROM items
;